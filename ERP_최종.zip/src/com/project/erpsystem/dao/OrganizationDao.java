package com.project.erpsystem.dao;

public class OrganizationDao {

}
