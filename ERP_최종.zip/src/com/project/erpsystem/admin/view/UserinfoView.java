package com.project.erpsystem.admin.view;

import java.util.Scanner;

import com.project.erpsystem.dao.PersonDepartmentDao;
//삭제하기
public class UserinfoView {
/*
	public static void changeDepartmentHierarchyView() {//인사발령등록뷰
		
		
		Scanner scan = new Scanner(System.in);
		
		
		System.out.println("------------------------");
		System.out.println("[인사발령 등록]");
		System.out.print("인사발령할 직원의 사번을 입력하세요:");
		String id = scan.nextLine();
		System.out.println("------------------------");
		
		PersonDepartmentDao.changeDepartmentHierarchy(id);
			

		
	}
	
	public static void changeEmployeeView() {//재직자정보수정메소드
		
		Scanner scan = new Scanner(System.in);
		String modifyitem;

		System.out.println("------------------------");
		System.out.println("[재직자 정보 수정]");
		System.out.print("수정할 직원의 사번을 입력하세요:");
		String id = scan.nextLine();

		PersonDepartmentDao.changeEmployee(id);
		
		

	}
	
	public static void newEmployeeView() {
		System.out.println("------------------------");
		System.out.println("[신규입사자 등록]");
		
		PersonDepartmentDao.newEmployee();
		
	}
	
	
	*/
}
