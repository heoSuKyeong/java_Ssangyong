package com.project.erpsystem.main;


public class Main {

	public static void main(String[] args) {
		InitialView.erpStart();
		
		
	}
}
