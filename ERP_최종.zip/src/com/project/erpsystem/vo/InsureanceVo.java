package com.project.erpsystem.vo;

public class InsureanceVo {

}
