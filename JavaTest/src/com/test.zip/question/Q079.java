package com.test.question;

public class Q079 {

	//마방진
//	아래와 같이 출력하시오.
//
//	출력..
//	2	7	6
//	9	5	1
//	4	3	8
	
	
	public static void main(String[] args) {
		
	}
	
}
