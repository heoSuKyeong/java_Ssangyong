package com.test.summary;

public class S001_DataType_Variable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//자료형 + 변수 + 리터럴
		//자료형 변수명 = 리터럴;
		int num = 10;
		int age;
		age = 10;
		
		
		

	}

}
